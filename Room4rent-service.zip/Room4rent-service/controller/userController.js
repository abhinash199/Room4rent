require('../utils/DBconnect');
const User = require('../model/user');
const addroom = require('../model/room');
var multer = require('multer');
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const jwt = require('jsonwebtoken')
const sendgridTransport = require('nodemailer-sendgrid-transport');
const transporter = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',

    port: 587,
    secure: false, // use SSL
    auth: {
        // api_key:"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"
        user: 'sharma.abhinash11@gmail.com',
        pass: 'Abhinash@123'
    }
})


const userSignup = async (req, res, next) => {

    console.log(req.body);

    const firstname = req.body.firstname ? req.body.firstname.toString() : '';
    const lastname = req.body.lastname ? req.body.lastname.toString() : '';
    const email = req.body.email ? req.body.email.toString() : '';
    const phone = req.body.phone ? req.body.phone.toString() : '';
    const password = req.body.password ? req.body.password.toString() : '';
    const gender="-";
    const dob="-";
    //const confirmpassword = req.body.confirmpassword ? req.body.confirmpassword.toString() : '';

    if (!firstname || !lastname || !email || !phone || !password) {
        return res.status(422).json({ error: "please add all the fields" })
    }
    User.findOne({ email: email })
        .then((savedUser) => {
            if (savedUser) {
                return res.status(422).json({ error: "user already exists with that email" })
            }
            bcrypt.hash(password, 12)
                .then(hashedpassword => {
                    const user = new User({
                        email,
                        password: hashedpassword,
                        firstname,
                        lastname,
                        phone,
                        gender,
                        dob
                    })

                    user.save()
                        .then(user => {
                            transporter.sendMail({
                                to: user.email,
                                from: "sharma.abhinash11@gmail.com",
                                subject: "signup success",
                                html: "<h1>welcome to instagram</h1>"
                            })
                            res.json({ message: "saved successfully" })
                        })
                        .catch(err => {
                            console.log(err)
                        })
                })

        })
        .catch(err => {
            console.log(err)
        })

}



const userSignin = (req, res, next) => {

    const { email, password } = req.body
    if (!email || !password) {
        return res.status(422).json({ error: "please add email or password" })
    }
    User.findOne({ email: email })
        .then(savedUser => {
            if (!savedUser) {
                return res.status(422).json({ error: "Invalid Email or password" })
            }
            bcrypt.compare(password, savedUser.password)
                .then(doMatch => {
                    if (doMatch) {
                        // res.json({message:"successfully signed in"})
                        const token = jwt.sign({ _id: savedUser._id }, process.env.SECRET_KEY)
                        console.log("my token", token);
                        const { _id, firstname, email, lastname, phone } = savedUser
                        res.json({ token, user: { _id, firstname, email, lastname, phone } })
                    }
                    else {
                        return res.status(422).json({ error: "Invalid Email or password" })
                    }
                })
                .catch(err => {
                    console.log(err)
                })
        })
    // try {
    //     console.log("req",req.body);


    //   const{email,password}=req.body;


    //     if ( !email ||!password) {
    //         return res.status(400).json({

    //             error: "Field cannot be empty"
    //         });
    //     }

    //     const userLogin = await User.findOne({
    //         email:email
    //     });

    //     if (userLogin) {
    //        const isMatch=await bcrypt.compare(password,userLogin.password);
    //        const token=await userLogin.generateAuthToken();
    //        console.log("token part",token);
    //        localStorage.setItem("token",token);
    //        res.cookie("jwttoken",token,{
    //            expires:new Date(Date.now()+25892000000),
    //            httpOnly:true
    //        });
    //        if(!isMatch){
    //            res.status(400).json({error:"Invalid credential"});
    //        }else{
    //            res.json({message:"sigin in successfull"});
    //        }
    //     } else{
    //         res.status(400).json({error:"Invlid credential"})
    //     }



    // }catch (err) {
    //     res.status(500).json({
    //         message: 'Something abhi wrong',
    //         error: true
    //     });
    // }

}
// const userSignup = async (req, res, next) => {
//     try {
//         console.log(req.body);

//         const firstname = req.body.firstname ? req.body.firstname.toString() : '';
//         const lastname=req.body.lastname?req.body.lastname.toString():'';
//         const email = req.body.email ? req.body.email.toString() : '';
//         const phone = req.body.phone ? req.body.phone.toString() : '';
//         const password=req.body.password?req.body.confirmpassword.toString():'';
//         const confirmpassword=req.body.confirmpassword ? req.body.confirmpassword.toString() :'';


//         if (!firstname ||!lastname|| !email || !phone||!password || !confirmpassword) {
//             return res.status(422).json({
//                 message: "missing fields are required",
//                 error: true
//             });
//         }

//         const userExist = await User.findOne({
//             email:email
//         });

//         if (userExist) {
//             return res.status(200).json({
//                 message: "Email is Already exist",
//                 error: true
//             });
//         } else {
//             const user = new User({
//                 firstname,
//                 lastname,
//                 email,
//                 password,
//                 confirmpassword,
//                 phone



//             });
//             user.save()
//             .then(user=>{
//                 transporter.sendMail({
//                     to:user.email,
//                     from:"sharma.abbhinash11@gmail.com",
//                     subject:"signup success",
//                     html:"<h1>welcome to instagram</h1>"
//                 })
//                 res.json({message:"saved successfully"})
//             })
//             .catch(err=>{
//                 console.log(err)
//             })

//             // user.save(function (err, doc) {
//             //     if (!err) {
//             //         res.status(200).json({
//             //             message: "Successfull",
//             //             error: false,
//             //             data: doc
//             //         });

//             //     } else {
//             //         res.status(500).json({
//             //             message: 'Error in save data',
//             //             error: true
//             //         });
//             //     } 
//             // })
//         }
//     } catch (err) {
//         res.status(500).json({
//             message: 'Something went wrong',
//             error: true
//         });
//     }
// }


const profiledata = (req, res, next) => {
    try {
        User.find().exec((err, obj) => {
            if (!err) {
                res.status(200).json({
                    data: obj,
                    error: false
                });
            } else {
                res.status(500).json({
                    message: 'Error in getting members list',
                    error: true
                });
            }

        });
    } catch (err) {
        res.status(500).json({
            message: 'Something went wrong',
            error: true
        });
    }
}

const roomdetail = (req, res) => {
    try {
        addroom.find().sort('-createdAt').exec((err, obj) => {
            if (!err) {
                res.status(200).json({
                    data: obj,
                    error: false
                });
            } else {
                res.status(500).json({
                    message: 'Error in getting members list',
                    error: true
                });
            }

        });
    } catch (err) {
        res.status(500).json({
            message: 'Something went wrong',
            error: true
        });
    }
}
const Addroom = async (req, res, next) => {
    try {
        console.log(req.body);
        const plotno = req.body.plotno ? req.body.plotno.toString() : '';
        const price = req.body.price ? req.body.price.toString() : '';
        const bhk = req.body.bhk ? req.body.bhk.toString() : '';
        const roomtype = req.body.roomtype ? req.body.roomtype.toString() : '';
        const address = req.body.address ? req.body.address.toString() : '';
        const postedid = req.body.postedid ? req.body.postedid.toString() : '';
        const imageName = req.body.imageName ? req.body.imageName.toString() : '';
        const status = req.body.status ? req.body.status.toString() : '';
        const water = req.body.water ? req.body.water.toString() : '';
        const category = req.body.category ? req.body.category.toString() : '';
        const teenager = req.body.teenager ? req.body.teenager.toString() : '';
        const uuid = req.body.uid ? req.body.uid.toString() : '';

        if (!teenager||!plotno || !price || !bhk || !roomtype || !address || !imageName || !uuid || !postedid || !status || !water || !category) {
            return res.status(422).json({
                message: "missing fields are required",
                error: true
            });
        }

        const plotExist = await addroom.findOne({
            plotno: plotno
        });

        if (plotExist) {
            return res.status(200).json({
                message: "PlotNO is Already exist",
                error: true
            });
        } else {
            const addrooms = new addroom({
                plotno,
                bhk,
                price,
                roomtype,
                address,
                water,
                imageName,
                status,
                category,
                postedid,
                teenager,
                uuid
            });
            addrooms.save(function (err, doc) {
                if (!err) {
                    res.status(200).json({
                        message: "Successfull",
                        error: false,
                        data: doc
                    });

                } else {
                    res.status(500).json({
                        message: 'Error in save data',
                        error: true
                    });
                }
            });
           
        }
    } catch (err) {
        console.log(err)
        res.status(500).json({
            message: 'Something went wrong',
            error: true
        });
    }
}
const Other = (req, res) => {
    console.log("id", req.params.id);
    User.findOne({ _id: req.params.id })
        .select("-password -confirmpassword")
        .then(user => {
            console.log(user);
            res.json([user])
        }).catch(err => {
            return res.status(404).json({ error: "User not found" })
        })

    // User.findOne({_id:req.params.id})
    // .select("-password")
    // .then(user=>{
    //      addroom.find({postedBy:req.params.id})
    //      .populate("postedBy","_id name")
    //      .exec((err,posts)=>{
    //          if(err){
    //              return res.status(422).json({error:err})
    //          }
    //          console.log({user});
    //          res.json({user,posts})
    //      })
    // }).catch(err=>{
    //     return res.status(404).json({error:"User not found"})
    // })


}

const uploadImage = (req, res, next) => {
    try {
        var storage = multer.diskStorage({
            destination: function (req, file, cb) {
                cb(null, 'public')
            },
            filename: function (req, file, cb) {
                cb(null, file.originalname)
            }
        })

        var upload = multer({
            storage: storage
        }).single('image')

        upload(req, res, function (err) {
            if (err instanceof multer.MulterError) {
                return res.status(500).json({
                    message: 'Error upload module',
                    error: true
                });
            } else if (err) {
                return res.status(500).json({
                    message: 'Error in image upload',
                    error: true
                });
            } else {
                res.status(200).json({
                    message: 'Image Upload Successfully',
                    error: false,
                    data: req.file
                });
            }
        })
    } catch (err) {
        return res.status(500).json({
            message: 'Something went wrong',
            error: true
        });
    }
}


const Mypost = (req, res, next) => {

    console.log("mypost", req.params.id);
    addroom.find({ postedid: req.params.id })
        .populate("postedid", "_id plot no bhk")
        .then(mypost => {
            console.log("mypost", mypost);
            res.json({ mypost })
        })
        .catch(err => {
            console.log(err)
        })

}
const fetchedit = (req, res, next) => {

    console.log("fetchedit", req.params.id);
    addroom.find({_id: req.params.id })
        .then(myfetchedit => {
            console.log("myfetchedit", myfetchedit);
            res.json({myfetchedit})
        })
        .catch(err => {
            console.log(err)
        })

}

const update = (req, res, next) => {

    console.log(req.body);
    const id=req.params.id
    User.findById(id, function (err, user) {
        if (!user)
            return next(new Error('Unable To Find Employee With This Id'));
        else {
            user.firstname = req.body.firstname;
            user.lastname = req.body.lastname;
            user.gender=req.body.gender;
            user.dob=req.body.dob;
            user.phone = req.body.phone;

            user.save().then(emp => {
                res.json('Employee Updated Successfully');
            })
                .catch(err => {
                    res.status(400).send("Unable To Update Employee");
                });
        }
    });


}


const fetchuser = (req, res, next) => {
    console.log("fetchuser", req.params.id);
    const id=req.params.id;
    User.findById(id)
    .then(myfetch => {
        console.log("myfetch", myfetch);
        res.json(myfetch)
    })
    .catch(err => {
        console.log(err)
    })

}


const mypostupdate = (req, res, next) => {
    console.log(req.body);
    const id=req.params.id
    console.log(id);
    addroom.findOne({_id:id}, function (err, user) {
        if (!user)
            return next(new Error('Unable To Find Employee With This Id'));
        else {
            console.log("user",user);
            user.plotno = req.body.plotno;
            user.bhk = req.body.bhk;
            user.category=req.body.category;
            user.price=req.body.price;
            user.roomtype = req.body.roomtype;
            user.status = req.body.status;
            user.water = req.body.water;
            user.address = req.body.address;
           
            user.save(function (err, doc) {
                if (!err) {
                    res.status(200).json({
                        message: "Successfull",
                        error: false,
                        data: doc
                    });

                } else {
                    res.status(500).json({
                        message: 'Error in save data',
                        error: true
                    });
                }
            });

           
        }
    });

}

const deletePost = (req, res, next) => {
    console.log("delepost", req.params.id);
    addroom.deleteOne({ _id: req.params.id }).then(result => {
        console.log(result);
        res.status(200).json({
            message: "Post deleted!"
        });
    })

}
const reset = (req, res, next) => {
    crypto.randomBytes(32, (err, buffer) => {
        if (err) {
            console.log(err)
        }
        const token = buffer.toString("hex")
        User.findOne({ email: req.body.email })
            .then(user => {
                if (!user) {
                    return res.status(422).json({ error: "User dont exists with that email" })
                }
                user.resetToken = token
                user.expireToken = Date.now() + 3600000
                user.save().then((result) => {
                    transporter.sendMail({
                        to: user.email,
                        from: "sharma.abhinash11@gmail.com",
                        subject: "password reset",
                        html: `
                    <p>You requested for password reset</p>
                    <h5>click in this <a href="http://localhost:3000/reset/${token}">link</a> to reset password</h5>
                    `
                    })
                    res.json({ message: "check your email" })
                })

            })
    })

}

const newpassword = (req, res, next) => {
    const newPassword = req.body.password
    const sentToken = req.body.token
    console.log("nwpass", req.body.password);
    console.log("token", req.body.token);
    User.findOne({ resetToken: sentToken, expireToken: { $gt: Date.now() } })
        .then(user => {
            if (!user) {
                return res.status(422).json({ error: "Try again session expired" })
            }
            bcrypt.hash(newPassword, 12).then(hashedpassword => {
                user.password = hashedpassword
                user.resetToken = undefined
                user.expireToken = undefined
                console.log("hasg", hashedpassword);

                user.save().then((saveduser) => {
                    res.json({ message: "password updated success" })
                })
            })

        }).catch(err => {
            console.log(err)
        })


}


module.exports = {
    userSignup,
    profiledata,
    Addroom,
    Other,
    Mypost,
    fetchuser,
    mypostupdate,
    update,
    reset,
    fetchedit,
    deletePost,
    uploadImage,
    userSignin,
    newpassword,
    roomdetail,
};