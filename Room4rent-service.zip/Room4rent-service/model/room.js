const mongoose=require("mongoose");
const AddroomSchema=new mongoose.Schema({
    plotno:String,
    bhk:String,
    price:Number,
    roomtype:String,
    address:String,
     imageName:String,
     status:String,
     teenager:String,
     water:String,
     category:String,
     postedid:String,
    uuid:String,
    // created_at: {type: Date, default: Date.now},
},{timestamps:Date.now})
module.exports =mongoose.model("Addroom",AddroomSchema);
  