const mongoose=require("mongoose");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const DataSchema=new mongoose.Schema({
    firstname:String,
    lastname:String,
    email:String,
    password:String,
   // confirmpassword:String,
   gender:String,
   dob:String,
    uuid:String,
    resetToken:String,
    expireToken:Date,
    phone:Number,
})
// DataSchema.pre('save',async function(next){
//     console.log("inside");
//     if(this.isModified('password')){
//         this.password=await bcrypt.hash(this.password,12);
//         this.confirmpassword=await bcrypt.hash(this.confirmpassword,12);

//     }
//     next();
//  })



// DataSchema.methods.generateAuthToken=async function(){
//     try{
//    let token=jwt.sign({_id:this._id},process.env.SECRET_KEY);
//    this.tokens=this.tokens.concat({token:token});
//    await this.save();
//    console.log("token")
//    return token;
//     }catch(err){
//         console.log(err);

//     }
// }
const User =mongoose.model("User",DataSchema);
module.exports=User
  
 //Api key
//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