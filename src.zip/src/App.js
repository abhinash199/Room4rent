
import { Route, Switch, useHistory } from 'react-router'
import Header from './components/Header'
import Home from './components/Home'
import Signup from './components/Signup'
import 'bootstrap/dist/css/bootstrap.min.css';
import Profile from './components/Profile';
import Addroom from "./components/Addroom";
import RoomDetail from "./components/RoomDetail";
import Signin from './components/Signin';
import About from "./components/About";
import UserProfile from "./components/UserProfile"
import MyProfile from './components/MyProfile';
import { BrowserRouter } from "react-router-dom";
import React, { useEffect, createContext, useContext, useReducer } from 'react';
import { reducer, initialState } from "./reducer/userReducer";
import Mypost from './components/Mypost'
import Reset from './components/Reset'
import Newpassword from './components/Newpassword'

export const UserContext = createContext();

const Routing = () => {
  const history = useHistory()
  const { state, dispatch } = useContext(UserContext);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"))
    console.log("user", user)
    if (user) {
      dispatch({ type: "USER", payload: user })
      history.push('/profile');
    }
  }, [])
  return (
    <>

      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/signup" component={Signup} />
        <Route path="/signin" component={Signin} />
        <Route exact path="/profile" component={Profile} />
        <Route exact path="/profile/my-account" component={MyProfile} />
        
        <Route exact path="/add-room" component={Addroom} />
        <Route exact path="/profile/room-detail" component={RoomDetail} />
       
        <Route path="/about" component={About} />
        <Route exact path="/reset" component={Reset} />
        <Route  path="/reset/:token" component={Newpassword} />
        <Route exact path="/profile/:userid">
          <UserProfile />
        </Route>
        <Route  path="/mypost/:stateid">
          <Mypost />
        </Route>
      </Switch>
    </>
  )
}
const App = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  
  return (
    <UserContext.Provider value={{ state, dispatch }}>
      <BrowserRouter>
     
        <Header/>
       <Routing/>

      </BrowserRouter>
    </UserContext.Provider>
  );
}

export default App
