import React, { useEffect, useState, useContext } from 'react';
import Pagination from "./Pagination";
import { Link } from "react-router-dom";
import "./roomdetail.css";
import { Card, CardGroup, Modal } from "react-bootstrap";
import { UserContext } from "../App";


const MEMBERS_IMAGE_URL = "http://localhost:4001/";
const Detail_API = "http://localhost:4001/profile/room-detail";

function RoomDetail() {

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);


    const [detail, setdetail] = useState();
    const [filteredData, setFilteredData] = useState(detail);
    const { state, dispatch } = useContext(UserContext);
    const [showPerPage, setshowPerPage] = useState(10);
    const [pagination, setpagination] = useState({
        start: 0,
        end: showPerPage,
    })

    const gedetail = async () => {
        try {
            const res = await fetch(Detail_API, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                }

            });
            const data = await res.json();
            setdetail(data.data)
            setFilteredData(data.data);
            console.log(data)
        } catch (err) {
            console.log(err);
        }
    }

    useEffect(() => {
        gedetail();

    }, [])
    const imageprev = () => {
        document.getElementById("image").style = "width:200px,height:200px";
    }
    const handleSearch = (event) => {
        if (event.target.value == "Available") {
            const result = detail.filter((data) => {
                return data.status == "Available"
            });
            console.log("result", result);
            setFilteredData(result);
        }


    }
    const handleSearch2 = (event) => {
        if (event.target.value == "Booked") {
            const result = detail.filter((data) => {
                return data.status == "Booked"
            });
            setFilteredData(result);
        }


    }
    const handleSearch3 = (event) => {
        if (event.target.value == "All") {
            const result = detail.filter((data) => {
                return data
            });
            setFilteredData(result);
        }


    }

    const onPaginationChange = (start, end) => {
        setpagination({
            start: start,
            end: end
        })
    }
    var a;
    return (
        <>
            <div>

                    {

                    filteredData === undefined || !filteredData.length ? "" :

                <div style={{ display: "inline-block", height: "100px", float: "right", margin: "30px", marginTop: "80px" }}>
                   <h6>Filter By:</h6>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="Available" onChange={(event) => handleSearch(event)} />
                        <label class="form-check-label" for="exampleRadios1">
                            Available
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="Booked" onChange={(event) => handleSearch2(event)} />
                        <label class="form-check-label" for="exampleRadios2">
                            Booked
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="All" onChange={(event) => handleSearch3(event)} />
                        <label class="form-check-label" for="exampleRadios2">
                            All
                        </label>
                    </div>
                </div>
                }
                <div>
                    {
                        console.log("filter", filteredData),
                        filteredData === undefined || !filteredData.length ? <h3 style={{ textAlign: "center", marginTop: "100px", color: "red" }}>Check your internet connection....!</h3> : filteredData.slice(pagination.start, pagination.end).map((i) => {
                            return (
                                <>
                                    <CardGroup className="mycardgroup" style={{ width: "400px", display: "inline-block",marginTop:"60px"}}>
                                        <Card>
                                            <Card.Header className="headercard"><img onClick={handleShow} id={i._id} style={{ width: "80px", height: "80px", cursor: "pointer" }} src={MEMBERS_IMAGE_URL + i.imageName} />
                                                <div style={{ color: "red", display: "inline-block", marginRight: "20px", float: "right" }}>

                                                    <h4>Rs.{i.price}</h4>
                                                    <h5 style={{ color: "blue", float: 'right', marginRight: "40px" }}>{i.bhk}</h5><br />
                                                    <h5>{i.status === "Booked" ? <h5 style={{ color: "red", marginLeft: "40px" }}>Booked</h5> : <h5 style={{ color: "green", marginLeft: "40px" }}>Available</h5>}</h5>
                                                </div>
                                            </Card.Header>
                                            <Card.Body className="cardbody">

                                                <Card.Text>
                                                    <h6 style={{ color: "#0e68aa" }}>Room Condition: <small style={{ color: "#000" }}>{i.roomtype}</small></h6><br />
                                                    <h6 style={{ color: "#0e68aa" }}>Tennager : <small style={{ color: "#000" }}>{i.teenager}</small></h6><br />
                                                    <h6 style={{ color: "#0e68aa" }}>Category: <small style={{ color: "#000" }}>{i.category}</small></h6><br />
                                                    <h6 style={{ color: "#0e68aa" }}>Address: <small style={{ color: "#000" }}>{i.plotno},{i.address}</small></h6><br />

                                                </Card.Text>
                                                <Card.Footer className="ownerback">
                                                    <Link to={"/profile/" + i.postedid}>Contact Owner</Link>
                                                   
                                                </Card.Footer>
                                               
                                                <h6 className="posted">Posted on: <small>{i.createdAt===undefined?"":i.createdAt.slice(0,10)}</small></h6>
                                            </Card.Body>

                                        </Card>
                                    </CardGroup>

                                    <Modal
                                        show={show}
                                        onHide={handleClose}
                                        backdrop="static"
                                        keyboard={false}
                                    >
                                        <Modal.Header closeButton>

                                        </Modal.Header>
                                        <Modal.Body>
                                            <label htmlFor={i._id}>
                                                <img style={{ width: "300px", height: "300px" }} src={MEMBERS_IMAGE_URL + i.imageName} />
                                            </label>
                                        </Modal.Body>

                                    </Modal>

                                </>
                            )
                        })









                    }
                </div>
                {
                    filteredData === undefined || !filteredData.length ? "" :
                <>
                <Pagination showPerPage={showPerPage} onPaginationChange={onPaginationChange} />

                <div class="footer-dark" fixed="bottom">
                    <footer>
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-6 col-md-3 item">
                                    <h3>Services</h3>
                                    <ul>
                                        <li><a href="#">Web design</a></li>
                                        <li><a href="#">Development</a></li>
                                        <li><a href="#">Hosting</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-6 col-md-3 item">
                                    <h3>About</h3>
                                    <ul>
                                        <li><a href="#">Company</a></li>
                                        <li><a href="#">Team</a></li>
                                        <li><a href="#">Careers</a></li>
                                    </ul>
                                </div>
                                <div class="col-md-6 item text">
                                    <h3>Company Name</h3>
                                    <p>Praesent sed lobortis mi. Suspendisse vel placerat ligula. Vivamus ac sem lacus. Ut vehicula rhoncus elementum. Etiam quis tristique lectus. Aliquam in arcu eget velit pulvinar dictum vel in justo.</p>
                                </div>
                                <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
                            </div>
                            <p class="copyright">Company Name © 2018</p>
                        </div>
                    </footer>
                </div>
                </>
                }
            </div>






        </>
    )
}


export default RoomDetail
