import React, { useState, useEffect, useContext } from 'react'

import { UserContext } from "../App";
import { useForm } from "react-hook-form";
import { useHistory } from "react-router-dom"
import "./myprofile.css";
import { Button } from 'react-bootstrap';
const UPDATE_API = "http://localhost:4001/update/";
const FETCHUSER_API = "http://localhost:4001/fetchuser/";
function MyProfile() {

    const history = useHistory();

    const [myprofile, setmyprofile] = useState([]);
    const { state, dispatch } = useContext(UserContext);

    const [Success, setSuccess] = useState(false)
    const [isSuccessfullySubmitted, setIsSuccessfullySubmitted] = useState(false);
    const [selectedFile, setselectedFile] = useState("");
    const { register, handleSubmit } = useForm();
    const [updateclick, setupdateclick] = useState(false);
    const [cancelClick, setCancelclick] = useState(false);


    //handle cancelClick
    const handleCancelclick = event => {
        setCancelclick(false);
        setupdateclick(false);
    }
    const onSubmit = (data) => {
        const { firstname, lastname, phone, gender } = data;
        console.log("data", data);

        const loggedInUser = localStorage.getItem("user");
        if (loggedInUser) {
            const foundUser = JSON.parse(loggedInUser);
            console.log("found", foundUser);


            fetch(
                `${UPDATE_API}${foundUser._id}`, {
                method: "PUT",
                body: JSON.stringify(data),
                headers: {
                    "Content-type": "application/json"
                },
            }).then(res => res.json())
                .then(data => console.log(data),
                    alert("updated successfully"),
                    history.push('/'),
                    window.location.reload()
                )

        }
    }
    useEffect(() => {
        const loggedInUser = localStorage.getItem("user");
        if (loggedInUser) {
            const foundUser = JSON.parse(loggedInUser);
            console.log("found", foundUser);

            fetch(`${FETCHUSER_API}${foundUser._id}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                }
            }).then(res => res.json())
                .then(data => setmyprofile(data)

                )
        }
    }, [])


    return (
        <>
            {
                console.log("my profile", myprofile)
               
            }
            { !myprofile?<h3 style={{ textAlign: "center", marginTop: "100px", color: "red" }}>Check your internet connection....!</h3>:
                <div className="container content">
                    <div className="row profile">
                        <div>


                        </div>
                        {
                            console.log(Success, isSuccessfullySubmitted)

                        }
                        <div>
                            {isSuccessfullySubmitted && !Success &&


                                <div className="success">Email sent successfully</div>


                            }
                            <div className="profile-content">
                                <ul className="nav-tabs">
                                    <li className="nav-item">
                                        General Information
                                    </li>
                                </ul>
                                <div className="profile-tab">
                                    <div>

                                        <div className="row">
                                            <div className="col-md-4 ">
                                                <label>First Name:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-8 py-2">

                                                    <input type="text" name="favCricketer" className="form-control"
                                                        defaultValue={myprofile.firstname}
                                                        {...register("firstname")}
                                                    />
                                                </div> :
                                                <div className="col-md-8">
                                                    <p>{myprofile.firstname}</p>
                                                </div>
                                            }


                                        </div>

                                        <div className="row">
                                            <div className="col-md-4">
                                                <label>Last Name:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-8 py-2" >
                                                    <input type="text" name="favCricketer" defaultValue={myprofile.lastname} className="form-control"
                                                        {...register("lastname")}
                                                    />
                                                </div> :
                                                <div className="col-md-8">
                                                    <p>{myprofile.lastname}</p>
                                                </div>
                                            }


                                        </div>

                                        <div className="row">
                                            <div className="col-md-4 ">
                                                <label>Phone No:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-8 py-2">
                                                    <input type="text" name="favCricketer" defaultValue={myprofile.phone} className="form-control"
                                                        {...register("phone")}
                                                    />
                                                </div> :
                                                <div className="col-md-8">
                                                    <p>{myprofile.phone}</p>
                                                </div>
                                            }


                                        </div>

                                        <div className="row">
                                            <div className="col-md-4">
                                                <label>Gender:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-8 py-2">
                                                    <select type="select" className="form-control" name="gender"
                                                        {...register("gender", { required: true })}
                                                    >
                                                        <option value="Male">Male</option>
                                                        <option value="Female">Female</option>

                                                    </select>
                                                </div> :
                                                <div className="col-md-8">
                                                 <p>{myprofile.gender}</p>
                                                </div>
                                            }
                                        </div>
                                        <div className="row">
                                            <div className="col-md-4 ">
                                                <label>Date of Birth:</label>
                                            </div>
                                            {updateclick ?
                                                <div className="col-md-8 py-2">
                                                    <input type="date" defaultValue={myprofile.dob}
                                                        {...register("dob")}
                                                    />
                                                </div> :
                                                <div className="col-md-8">
                                                    <p>{myprofile.dob}</p>
                                                </div>
                                            }
                                        </div>


                                        <div>
                                            {!updateclick ? <Button onClick={(e) => setupdateclick(true)}>Edit</Button> : ''}

                                            {updateclick ?
                                                <Button variant="success" onClick={handleSubmit(onSubmit)} style={{ margin: "10px" }}>Save</Button> : ''}
                                            {updateclick ? <Button variant="danger" onClick={(e) => handleCancelclick(e)}>Cancel</Button>
                                                : ''}
                                        </div>



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            }


        </>
    )
}

export default MyProfile
