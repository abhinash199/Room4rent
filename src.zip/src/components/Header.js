import axios from 'axios';
import React, { useContext, useState, useEffect } from 'react'
import { Navbar, Container, Nav, Button } from "react-bootstrap"
import { useHistory, Link } from "react-router-dom";
import { UserContext } from "../App";
const FETCHUSER_API = "http://localhost:4001/fetchuser/";
function Header() {
  const initialState = "0px";
  const [navWidth, setnavWidth] = useState(initialState);
  const [fetchuser, setfetchuser] = useState([]);
  const opennav = () => {
    setnavWidth("250px");
  }
  const closenav = () => {
    setnavWidth("0px");
  }
  const { state, dispatch } = useContext(UserContext);
  const history = useHistory();
  const handleSignup = () => {
    history.push('/signup')
  }




  useEffect(() => {
    const loggedInUser = localStorage.getItem("user");
    if (loggedInUser) {
      const foundUser = JSON.parse(loggedInUser);
      console.log("found", foundUser);

      fetch(`${FETCHUSER_API}${foundUser._id}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        }
      }).then(res => res.json())
        .then(data => setfetchuser(data)
       
        )
    }

  }, [])







const RenderMenu = () => {
  console.log("state", state)

  if (state) {

    return (
      <>
        <Navbar bg="primary" variant="dark" fixed="top">
          <Container>
            <span className="menulines" onClick={opennav}>&#9776;</span>

            <Link to="/profile"><span style={{ fontWeight: "bold",fontSize:"20px",color:"cyan" }}>ROOM<span style={{color:"sandybrown",fontSize:"20px"}}>4</span>RENT</span></Link>
            <Nav className="mr-auto">
              <Link to="/profile/room-detail">
                Find Room
              </Link>

              <Link to="/add-room">Post Room</Link>
             
              <Link to="/profile/my-account">My Profile</Link>
              <Link to={'/mypost/' + state._id}>My Post</Link>
              <Link to="/about">About us</Link>
             
            </Nav>
          </Container>


          <Button variant="danger" className="dangerbutton" onClick={() => {
            localStorage.clear()
            dispatch({ type: "CLEAR" });
            history.push('/');
          }}>Logout</Button>

        </Navbar>
        <div className="sidenav" id="mySidenav" style={{ width: `${navWidth}`, transition: "all 0.5s" }}>
          <a href="javascript:void(0)" className="closebtn" onClick={closenav}>&times;</a>
          <h4 className="cricket">Hi,{fetchuser.firstname}{console.log("myfetch",fetchuser)}</h4>
          <a href="/">Home</a>
          <Link onClick={closenav} to="/profile/room-detail">
            Find Room
          </Link>

          <Link onClick={closenav} to="/add-room">Post Room</Link>
          

          <Link onClick={closenav} to="/profile/my-account">
            My Profile
          </Link>
          { }
          <Link onClick={closenav} to={'/mypost/' + state._id}>
            My Post
          </Link>
          <Link onClick={closenav} to="/about">About us</Link>
          <Link onClick={closenav} onClick={(e) => {
            e.preventDefault();
            localStorage.clear()
            dispatch({ type: "CLEAR" });
            history.push('/');
          }}>
            Logout
          </Link>

        </div>
      </>

    )
  } else {
    return (
      <>
        <Navbar bg="primary" variant="dark" fixed="top">
          <Container>
            <Navbar.Brand href="/"><span style={{ fontWeight: "bold",fontSize:"20px",color:"cyan" }}>ROOM<span style={{color:"sandybrown",fontSize:"20px"}}>4</span>RENT</span></Navbar.Brand>
            <Nav className="mr-auto">
              <Link to="/signin">
                Find Room
              </Link>

              <Link to="/signin">Post Room</Link>
              <Link to="/about">About us</Link>
             
            </Nav>
          </Container>
          <a href="/signin" style={{ color: "white" }}>Login</a>

          <Button variant="danger" onClick={handleSignup}>Signup</Button>

        </Navbar>

      </>
    )
  }
}

return (
  <>
    <RenderMenu />
  </>

)
}

export default Header
