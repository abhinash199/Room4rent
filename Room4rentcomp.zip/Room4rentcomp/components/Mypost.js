import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';

import { Card, Button, Modal, CardGroup } from "react-bootstrap";
import { useForm } from "react-hook-form";
const MEMBERS_IMAGE_URL = "http://localhost:4001/";
const MYPOST_API = "http://localhost:4001/mypost/";
const DELETE_API = "http://localhost:4001/deletepost/";
const FETCHEDIT_API = "http://localhost:4001/fetchedit/";
const MYPOSTUPDATE_API = "http://localhost:4001/mypostupdate/";

function Mypost() {
    const { stateid } = useParams();
    const [EditPost, setEditPost] = useState([]);
    const [FetchEdit, setFetchEdit] = useState([]);
  
    const [Editid, setEditid] = useState("");
    const [mypost, setmypost] = useState();
    const [updateclick, setupdateclick] = useState(false);
    const { register, handleSubmit, formState: { errors } } = useForm();
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    console.log("userid", stateid);
    console.log("editid",Editid);
    const setFetchEdit2 =()=>{
        setFetchEdit([])
    }
    const onclickedit=(item)=>{
        console.log("id=",item);
        const{_id,plotno,
            bhk,
            roomtype,
            category,
            status,
            water,
            price,
            address}=item
        // fetch(`${FETCHEDIT_API}${id}`, {
        //     method: "get",
           
        // }).then(res=>res.json())

        // .then(data=>{
        //     console.log("dtatda",data.myfetchedit)
        //     setFetchEdit(data.myfetchedit)       
        // }
        // )
 setFetchEdit({
     _id,plotno,
    bhk,
    roomtype,
    category,
    status,
    water,
    price,
    address})
       
        console.log("fetch",FetchEdit)
    }

    const deletePost = (postid) => {
        console.log("postid", postid);
        fetch(`${DELETE_API}${postid}`, {
            method: "delete",
            headers: {
                Authorization: "Bearer " + localStorage.getItem("jwt")
            }
        }).then(() => {
            setmypost(

                mypost.filter((val) => {
                    return val._id == !postid;
                })

            )
            window.alert("your post is deleted")
            window.location.reload();
        })

    }
    // const onFileChange = event => {
    //     const file = event.target.files[0];
    //     setselectedFile(file);
    // };
    const onSubmit = (data) => {

        const loggedInUser = localStorage.getItem("user");
        if (loggedInUser) {
            const foundUser = JSON.parse(loggedInUser);
            console.log("found", foundUser);


            const requestOptions = {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            };
            fetch(`${MYPOSTUPDATE_API}${Editid}`, requestOptions)
                .then(response => response.json())
                .then(data => setmypost(data.mypost));
            window.alert("updated successfully");
            window.location.reload();
        }
    }

    const fetchMypost = async () => {
        try {
            const res = await fetch(`${MYPOST_API}${stateid}`, {
                method: "GET",
                headers: {
                    "Authorization": "Bearer " + localStorage.getItem("jwt")
                }

            });
            const data = await res.json();

            setmypost(data.mypost)
            console.log("mypostabhi", data)


        } catch (err) {
            console.log(err);
        }
    }
    useEffect(() => {
        fetchMypost();
    }, [])




    return (
        <>
            {

                console.log("len", mypost ? mypost : ""),
                mypost == undefined || !mypost.length ? <h3 style={{ marginTop: "90px",color:"red",textAlign:"center" }}>Sorry...! You haven't posted yet</h3> : mypost.map((item) => (

                    <>
                        <CardGroup className="mycardgroup" style={{ width: "400px", display: "inline-block", marginTop: "75px" }}>
                            <Card>
                                <Card.Header className="headercard"><img style={{ width: "80px", height: "80px" }} src={MEMBERS_IMAGE_URL + item.imageName} />
                                    <div style={{ color: "red", display: "inline-block", marginRight: "20px", float: "right" }}>

                                        <h4>Rs.{item.price}</h4>
                                        <h5 style={{ color: "blue", float: 'right', marginRight: "40px" }}>{item.bhk}</h5><br />
                                        <h5>{item.status === "Booked" ? <h5 style={{ color: "red", marginLeft: "40px" }}>Booked</h5> : <h5 style={{ color: "green", marginLeft: "40px" }}>Available</h5>}</h5>
                                    </div>
                                </Card.Header>
                                <Card.Body className="cardbody">

                                    <Card.Text>
                                        <h6 style={{ color: "#0e68aa" }}>Room Condition: <small style={{ color: "#000" }}>{item.roomtype}</small></h6><br />
                                        <h6 style={{ color: "#0e68aa" }}>Teenager: <small style={{ color: "#000" }}>{item.teenager}</small></h6><br />
                                        <h6 style={{ color: "#0e68aa" }}>Category: <small style={{ color: "#000" }}>{item.category}</small></h6><br />
                                        <h6 style={{ color: "#0e68aa" }}>Address: <small style={{ color: "#000" }}>{item.plotno},{item.address}</small></h6><br />

                                    </Card.Text>

                                </Card.Body>
                                <h6 className="myposted">Posted: <small>{item.createdAt===undefined?"":item.createdAt.slice(0,10)}</small></h6>

                            </Card>
                            <div style={{ marginLeft: "100px", marginTop: "10px" }}>
                                <Button variant="danger" id="deletepost" onClick={() => deletePost(item._id)}>Delete Post</Button>
                                {/* <Button variant="info" id="editpost" onClick={()=>{setEditPost([item._id,item.plotno,item.bhk,item.roomtype,item.category,item.status,item.water,item.price,item.address]);handleShow()}}  style={{ color: "white" }}>Edit Post</Button>
                            */}
                             <Button variant="info" id="editpost" onClick={()=>{setEditid(item._id);onclickedit(item);handleShow()}}  style={{ color: "white" }}>Edit Post</Button>
                           
                            </div>
                        </CardGroup>





                        <Modal
                          
                            show={show}
                            onHide={handleClose}
                            backdrop="static"
                            keyboard={false}
                        >                                    {console.log("fetchedit2",FetchEdit)}

                            <Modal.Header closeButton style={{background:"blue",color:"white"}}>
                                <Modal.Title>Edit Post{FetchEdit?FetchEdit._id:""}</Modal.Title>
                            </Modal.Header>
                            <form onSubmit={handleSubmit(onSubmit)} encType="multipart/form-data">
                                <Modal.Body>
                                    <label>Plot No.</label><br/>
                                    <div className="form-group">
                                        <input type="number" className="form-control" 
                                            {...register("plotno", { required: "required" })}
                                        />

                                    </div>
                                    <label>Category:</label><br/>
                            <div className="form-group">
                                <select type="select" className="form-control" name="status" 
                                                        {...register("category", { required: true })}
                                                   >    
                                                     <option value="">select</option>
                                                        <option value="Apartment">Apartment</option>
                                                        <option value="Building">Building</option>
                                                        <option value="Multi-complex">Multi-complex</option>
                                                        <option value="Row House">Row House</option>
                                                      
                                                  </select>

                            </div>
                                    <label>Room Type</label><br/>
                                    <div className="form-group">
                                        <select type="select" className="form-control" name="bhk" 
                                            {...register("bhk", { required: true })}
                                        >
                                            <option>1BHK</option>
                                            <option>2BHK</option>
                                            <option>3BHK</option>
                                            <option>Single room</option>
                                        </select>

                                    </div>
                                    <label>Status</label><br/>
                                    <div className="form-group">
                                        <select type="select" className="form-control" name="status" 
                                            {...register("status", { required: true })}
                                        >
                                            <option value="Available">Available</option>
                                            <option value="Booked">Booked</option>

                                        </select>

                                    </div>
                                    <label>Water supply</label><br/>
                            <div className="form-group">
                                <select type="select" className="form-control" name="water"
                                                        {...register("water", { required: true })}
                                                   >
                                                        <option>select</option>
                                                        <option>Borewell</option>
                                                        <option>Tanker</option>
                                                        <option>Other</option>
                                                  </select>

                            </div>
                                    <label>Room Price (without electricity)</label><br/>
                                    <div className="form-group">
                                        <input type="number" className="form-control" placeholder="price" 
                                            {...register("price", { required: true })}
                                        />

                                    </div>
                                    <label>Room Condition</label><br/>
                                    <div className="form-group">
                                        <select type="select" className="form-control" name="roomtype" 
                                            {...register("roomtype", { required: true })}
                                        >
                                            <option>Room Type</option>
                                            <option>New</option>
                                            <option>0-1 year old</option>
                                            <option>1-2 year old</option>
                                            <option>2-3 year old </option>
                                            <option>more than 3 year old </option>
                                        </select>

                                    </div>
                                    <label>Room Address</label><br/>
                                    <div className="form-group">
                                        <input type="text" className="form-control" placeholder="Your Home Address"
                                            {...register("address", { required: true })}
                                        />

                                    </div>
                                    {/* <div className="form-group py-2">
                                <input type="file" className="form-control" placeholder="Your Home Address" accept="image/*"
                                   onChange={onFileChange}
                                />

                            </div> */}

                                </Modal.Body>
                                <Modal.Footer>
                                    <Button variant="danger" onClick={ handleClose}>
                                        Close
                                    </Button>
                                    <Button type="submit" variant="primary">save</Button>

                                </Modal.Footer>
                            </form>
                        </Modal>
                    </>
                ))

            }



        </>
    )
}






export default Mypost

