import React,{useState} from 'react'
import {useHistory,useParams} from 'react-router-dom'
const NEWPASSWORD_API = "http://localhost:4001/newpassword/";
const Newpassword  = ()=>{
    const history = useHistory()
    const [password,setPasword] = useState("")
    const {token} = useParams();
    console.log(token)
    const PostData = ()=>{
        fetch(NEWPASSWORD_API,{
            method:"post",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({
                password,
                token
            })
        }).then(res=>res.json())
        .then(data=>{
            
            console.log(data)
           if(data.error){
              //M.toast({html: data.error,classes:"#c62828 red darken-3"})
              alert("error")
           }
           else{

              window.alert("successs")
               history.push('/signin')
           }
        }).catch(err=>{
            console.log(err)
        })
    }
   return (
    <div className="login-form">
    <form>
      <h1>New Password</h1>
      <div className="form-group">
        <input type="password" name="password" value={password} placeholder="new password"onChange={(e)=>setPasword(e.target.value)} required/>
        <span className="input-icon"><i className="fa fa-envelope"></i></span>
      </div>
          
      <button className="login-btn" onClick={PostData}>Update</button>      
     
      
      
    </form>
  </div>
   )
}
export default Newpassword