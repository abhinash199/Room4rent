import React,{useState,useContext} from 'react'
import {UserContext} from "../App"
import {useHistory } from "react-router-dom";
const SIGNIN_API = "http://localhost:4001/signin";
function Signin() {
   ;
    const history=useHistory();
     const {state,dispatch} = useContext(UserContext);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
     const LoginUser = (e) => {
           e.preventDefault();
          
       fetch(SIGNIN_API,{
            method:"post",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({
                password,
                email
            })
        }).then(res=>res.json())
        .then(data=>{
            console.log(data)
           if(data.error){
              alert("invalid")
           }
           else{
               localStorage.setItem("jwt",data.token)
               localStorage.setItem("user",JSON.stringify(data.user))
               dispatch({type:"USER",payload:data.user})
                window.alert("Signin successfull");
                history.push("/");
                window.location.reload();
               
           }
        }).catch(err=>{
            console.log(err)
        })
           
       
      
    
    }
    return (

        <div className="login-form">
    <form>
      <h1>Login</h1>
      <div className="form-group">
        <input type="email" name="email" value={email} placeholder="E-mail Address"onChange={(e)=>setEmail(e.target.value)} required/>
        <span className="input-icon"><i className="fa fa-envelope"></i></span>
      </div>
      <div className="form-group">
        <input type="password" name="psw" placeholder="Password"  onChange={(e)=>setPassword(e.target.value)} value={password} required/>
        <span className="input-icon"><i className="fa fa-lock"></i></span>
      </div>      
      <button className="login-btn" onClick={LoginUser}>Login</button>      
      <a className="reset-psw" href="/reset">Forgot your password?</a>
      
      <p>New User?<a style={{color:"blue"}} href="/signup">Signup</a></p>
      
      
    </form>
  </div>
       
    )
}

export default Signin
