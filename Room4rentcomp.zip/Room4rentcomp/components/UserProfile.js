import React,{useEffect,useState,useContext} from 'react'
import {UserContext} from "../App"
import {useParams} from 'react-router-dom'
import "./user.css";
const OTHERUSER_API = "http://localhost:4001/user/";
function UserProfile() {
     const {state,dispatch} = useContext(UserContext);
     const [userProfile,setProfile] = useState([]);
    const {userid} = useParams();
      console.log("userid",userid);

      const fetchUser=async()=>{
        try{
            const res=await fetch(`${OTHERUSER_API}${userid}`,{
                method:"GET",
                headers:{
                    "Authorization":"Bearer "+localStorage.getItem("jwt")
                }
           
            });
            const data=await res.json();
            setProfile(data)
            console.log(data)
         }catch(err){
    console.log(err);
         }
      }
     useEffect(()=>{
      fetchUser();
    },[])
    return (
        
<>
<div style={{background:"linear-gradient(#0250c5,#d43f8d)",height:"100vh"}}>


        {

            console.log("userprofile",userProfile),
        userProfile===undefined?<h2>Loading</h2>:userProfile.map((items)=>(
            <>
          
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card user-card">
                {/* <div class="card-header">
                    <h5>Profile</h5>
                </div> */}
                <div class="card-block">
                    <div class="user-image">
                        <img src="https://bootdey.com/img/Content/avatar/avatar7.png" class="img-radius" alt="User-Profile-Image"/>
                    </div>
                    <h4 class="f-w-600 m-t-25 m-b-10">{items.firstname} {items.lastname}</h4>
                     <div className="row w-100">
                         <div className="col-md-12">
                             <div className="box">
                             <h6>Phone:<span>{items.phone}</span></h6>
                           <h6>Gender:<span>{items.gender}</span></h6>
                           <h6>DOB:<span>{items.dob}</span></h6>
                             </div>
                          
                         </div>
                        


                     </div>
                   
                   
                    
                   
                </div>
            </div>
        </div>
        
       
        
	</div>
</div>
            </>
        ))}
</div>
       </>
    )
}

export default UserProfile
