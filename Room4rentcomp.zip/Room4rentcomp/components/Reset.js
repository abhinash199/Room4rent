import React,{useState} from 'react'
import { useHistory } from "react-router-dom";
const RESET_API = "http://localhost:4001/reset";
function Reset() {
   
    const history=useHistory();
    
    const [email, setEmail] = useState('');
   
     const ResetPassword = (e) => {
           e.preventDefault();
          
       fetch(RESET_API,{
            method:"post",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify({
               
                email
            })
        }).then(res=>res.json())
        .then(data=>{
           
           if(data.error){
              alert("invalid")
           }
           else{
              
             
                window.alert("Check your emails");
                history.push("/signin");
               
           }
        }).catch(err=>{
            console.log(err)
        })
           
       
      
    
    }
    return (

        <div className="login-form">
    <form>
      <h1>Reset Password</h1>
      <div className="form-group">
        <input type="email" name="email" value={email} placeholder="E-mail Address"onChange={(e)=>setEmail(e.target.value)} required/>
        <span className="input-icon"><i className="fa fa-envelope"></i></span>
      </div>
          
      <button className="login-btn" onClick={ResetPassword}>Reset</button>      
     
      
      
    </form>
  </div>
         
    )
}

export default Reset
