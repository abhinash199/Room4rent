import React from 'react'
import "./profile.css";
import Home from "./Home";

function Profile() {
  
    return (
       <>
     <Home />
       
       
      
 
       </>
    )
}

export default Profile
