import React from 'react'
import "./signup.css";
import { Link,useHistory} from 'react-router-dom';
import { useForm } from "react-hook-form";
import axios from "axios";
const SIGNUP_API = "http://localhost:4001/signup";
function Signup() {
    const history=useHistory();
    const { register, handleSubmit  ,formState: { errors }} = useForm();

    const onSubmit = (data) => {
        console.warn(data)
        if(!data.password){
            alert("password and confirmpassword should match");
        }else{

        

        const signUpConfig = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        axios.post(
            SIGNUP_API,
            JSON.stringify(data),
            signUpConfig
        ) .then(res => {
            if (res.status === 200 && res.data && res.data.error) {
                window.alert("Email ID is already exist");
            } else {
                window.alert("Registered Successfull");
                        console.log("Save Successfull");
                      history.push('/signin');
                
                  
            }
        }).catch(err=>{
            console.log(err);
        })

    }
    }
    return (
        <>
            <div className="limiter">
                <div className="container-login100">
                    <div className="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
                        <form className="login100-form validate-form" onSubmit={handleSubmit(onSubmit)}>
                            <span className="login100-form-title p-b-55">
                                Signup
                            </span>

                            <div className="form-group py-2">
                                <input type="text" className="form-control" placeholder="First Name"
                                    {...register("firstname", { required: "required" ,pattern: /[A-Za-z]{4}/})}
                                />
                                 {errors.firstname && (<small className="text-danger">This Field is Required</small>)}

                            </div>
                            <div className="form-group py-2">
                                <input type="text" className="form-control" placeholder="Last Name"
                                    {...register("lastname", { required: "required" , pattern:/[A-Za-z]{4}/})}
                                />
                                 {errors.lastname && (<small className="text-danger">This Field is Required</small>)}


                            </div>
                            <div className="form-group py-2">
                                <input type="email" className="form-control" placeholder="Email"
                                    {...register("email", { required: "required" })}
                                />
                                  {errors.email && (<small className="text-danger">This Field is Required</small>)}

                            </div>
                            <div className="form-group py-2">
                                <input type="password" className="form-control" placeholder="password"
                                    {...register("password", {required:"true", minLength:8 })}
                                />
                                 {errors.password && (<small className="text-danger">This Field is Required</small>)}


                            </div>
                            {/* <div className="form-group py-2">
                                <input type="password" className="form-control" placeholder="confirm password"
                                    {...register("confirmpassword", {required:"true",minLength:8})}
                                />
                                 {errors.confirmpassword&&(<small className="text-danger">This Field is Required</small>)}


                            </div> */}
                            <div className="form-group py-2">
                                <input type="phone" className="form-control" placeholder="phone"
                                    {...register("phone", { required: "required" })}
                                />
                                 {errors.phone && (<small className="text-danger">This Field is Required</small>)}


                            </div>
                            <div className="container-login100-form-btn p-t-25">
                                <button className="login100-form-btn">
                                    Signup
                                </button>
                            </div>


                            <div className="text-center w-full p-t-115">
                                <span className="txt1">
                                  Already Member
                                </span>
                               <Link to="/signin" className="sign">Login</Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Signup;
