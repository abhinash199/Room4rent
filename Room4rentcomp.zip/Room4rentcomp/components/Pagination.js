import React, { useState, useEffect } from 'react'

const Pagination = ({ showPerPage, onPaginationChange }) => {
    const [counter, setcounter] = useState(1)
    //const [numberOfButton, setNumberOfButton] = useState(Math.ceil(total.showPerPage))
    useEffect(() => {
        const value = showPerPage * counter;
        onPaginationChange(value - showPerPage, value);
    }, [counter])
    const onButtonClick = (type) => {
        if (type == 'prev') {
            if (counter === 1) {
                setcounter(1)
            } else {
                setcounter(counter - 1);
            }
        } else if(type==='next'){
            setcounter(counter+1);
        }


    }
    return (
        <div className="d-flex justify-content-end">
            <nav aria-label="Page navigation example">
                <ul className="pagination">
                    <li className="page-item"><a className="page-link" href="!#" onClick={() => onButtonClick('prev')}>Previous</a></li>
                    <li className="page-item"><a className="page-link" href="#">1</a></li>
                   
                    <li className="page-item"><a className="page-link" href="!#" onClick={() => onButtonClick('next')}>Next</a></li>
                </ul>
            </nav>
            <button className="btn btn-primary" onClick={() => onButtonClick('prev')}>Previous</button>
            <button className="btn btn-primary" onClick={() => onButtonClick('next')}>Next</button>
        </div>
    )
}

export default Pagination
