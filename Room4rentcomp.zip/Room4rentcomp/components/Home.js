import React,{useContext}from 'react'
import { Carousel, CardGroup, Card } from "react-bootstrap";
import home from "../home.jfif";
import search from "../search.jfif";
import gallery from "../gallery2.jfif";
import about from "../about.jfif";
import room from "../room.jfif";
 import {UserContext} from "../App";
 import {Link} from "react-router-dom";
function Home() {
  const {state,dispatch} = useContext(UserContext);
    return (
        <div>
            <>
             <Carousel fade>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://dyimg1.realestateindia.com/proj_images/project31378/proj_header_image-31378-770x400.jpg"
            alt="First slide"
          />

        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://dyimg1.realestateindia.com/proj_images/project31378/proj_header_image-31378-770x400.jpg"
            alt="Second slide"
          />


        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://dyimg1.realestateindia.com/proj_images/project31378/proj_header_image-31378-770x400.jpg"
            alt="Third slide"
          />


        </Carousel.Item>
      </Carousel>
      <section className="section-btn">
        <div className="section-inner ourclubs">
          <img src={room} alt="room" style={{width:"200px",height:"200px",float:"left",margin:"20px",paddingLeft:"20px"}}/>
          <h2>Looking For Room</h2>
          <p>To succeed, you need to find something to hold on to, something to motivate you, something to inspire you.</p>
          <p className="btn-default"><Link to= {state?"/profile/room-detail":"/signin"}>Find</Link></p>

        </div>
      </section>
      <section className="section w-100">
        <CardGroup>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={home} />
              <Card.Title className="title">Post/Rent Your House</Card.Title>
              <Card.Text>
                Now you can digitalise your house
              </Card.Text>
            </Card.Body>

            <Card.Footer>
              <Link to={state?"/add-room":"/signin"}>
                <small className="text-muted">Post your House -&gt;</small>
              </Link>
            </Card.Footer>

          </Card>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={search} />
              <Card.Title className="title">Find room near you</Card.Title>
              <Card.Text>
                Now you can easily search room near you
              </Card.Text>
            </Card.Body>
            <Card.Footer>
              <Link to={state?"/profile/room-detail":"/signin"}>
                <small className="text-muted">Search for room -&gt;</small>
              </Link>
            </Card.Footer>
          </Card>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={gallery} />
              <Card.Title className="title">Happy Moments</Card.Title>
              <Card.Text>
                Here you can see the photos of happy moments
              </Card.Text>
            </Card.Body>
            <Card.Footer>
              <a href="#">
                <small className="text-muted">Click to view -&gt;</small>
              </a>
            </Card.Footer>
          </Card>
          <Card className="cardhover">

            <Card.Body>
              <Card.Img className="image" src={about} />
              <Card.Title className="title">Know about more</Card.Title>
              <Card.Text>
                From here we can get more info about this website
              </Card.Text>
            </Card.Body>
            <Card.Footer>
              <a href="#">
                <small className="text-muted">Need more info -&gt;</small>
              </a>
            </Card.Footer>
          </Card>
        </CardGroup>
      </section>
      <section style={{height:"300px"}}>

      </section>
      <div className="footer-dark" fixed="bottom">
        <footer>
            <div className="container">
                <div className="row">
                    <div className="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div className="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div className="col-md-6 item text">
                        <h3>Company Name</h3>
                        <p>Praesent sed lobortis mi. Suspendisse vel placerat ligula. Vivamus ac sem lacus. Ut vehicula rhoncus elementum. Etiam quis tristique lectus. Aliquam in arcu eget velit pulvinar dictum vel in justo.</p>
                    </div>
                    <div className="col item social"><a href="#"><i className="icon ion-social-facebook"></i></a><a href="#"><i className="icon ion-social-twitter"></i></a><a href="#"><i className="icon ion-social-snapchat"></i></a><a href="#"><i className="icon ion-social-instagram"></i></a></div>
                </div>
                <p className="copyright">Company Name © 2018</p>
            </div>
        </footer>
    </div>
    </>
        </div>
    )
}

export default Home
